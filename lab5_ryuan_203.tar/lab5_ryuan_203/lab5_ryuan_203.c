#include <stdio.h>
#include <stdlib.h>
#define size 50

int main(int argc, char **argv)
{

    char inBuff[size], name[size], course[size], comma;
    int rows, gNum, semester, credits, i;
    float grade;

    FILE *pt;
    FILE *qt;

    pt = fopen(argv[1], "r");
    qt = fopen(argv[2], "w");

    if (pt == NULL)
    {
        printf("Input files name error. Cannot open it. Exit the program.\n");
        exit(-1);
    }

    fgets(inBuff, size, pt);
    sscanf(inBuff, "%i", &rows);

    for (i = 0; i < rows; i++)
    {

        fgets(inBuff, size, pt);
        sscanf(inBuff, "%i %[^,] %c %i %s %i %f", &gNum, name, &comma, &semester, course, &credits, &grade);

        fprintf(qt, "%-25s %-10i %-8.2f %-10s %-3i  %-3i \n", name, gNum, grade, course, credits, semester);
    }

    fclose(pt);
    fclose(qt);

    return 0;
}